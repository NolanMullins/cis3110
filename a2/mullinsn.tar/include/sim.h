#ifndef __MULLINSN_SIM__
#define __MULLINSN_SIM__

void fcfs(Data* data, int detail, int verbose);
void  RR(Data* data, int detail, int verbose, int quantum);

#endif