#ifndef __MULLINSN_PARSE__
#define __MULLINSN_PARSE__

Data* parseFile(char* fileName);

#endif