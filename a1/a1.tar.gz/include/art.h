#ifndef __MULLINSN_ART__
#define __MULLINSN_ART__

//star wars
//telnet towel.blinkenlights.nl

void initArt();
void randomArt();

//art
void welcome();
void baseball();
void computer();
void spongebob();
void thumbUp();
void linux();
void sadPepe();

#endif